for f in range(1,11):
	multiplicacion = 7 * f #hacemos la multiplicación
	print(f'7 x {f} = {multiplicacion}') #mostramos el resultado